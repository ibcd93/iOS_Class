//
//  ViewController.swift
//  Calculator
//
//  Created by Bharathiraja Nagappan on 9/9/17.
//  Copyright © 2017 Bharathiraja Nagappan. All rights reserved.
//

import UIKit

class ViewController: UIViewController {
  
    var convert_number : Double = 0 // initalizes the variable which is used later to store the first number entered by the user (which will be converted from a string to a double)
    var first_number: Double = 0 //this is where it will store a number and we are intiallizing to 0
    var do_math = false // tells the program that a math function has been pressed
                        // this will allow the program to store the first number and then allow the use to enter a second number
    var operation = 0 // initalizes the variable which is used later on in the code to store the operation                 the user chooses
    
    @IBAction func numbers(_ sender: UIButton) { //all of the number buttons are put into this function
        
        //This was done by giving all of the numbers a specific tag. in this case i started from 1 up to 10
        //makes it easier to code instead of having 10 different variables to deal with
        
        
        if do_math == true { //this is to check if a math function has been pressed
            calc_view.text = String(sender.tag - 1) //this allows us to locate the tag and display the number
            convert_number = Double(calc_view.text!)! //converts the string into a double
            do_math = false
        }
        else{ //if not then the view will continue to add onto the values that have already been pressed
            calc_view.text = calc_view.text! + String(sender.tag - 1)
            convert_number = Double(calc_view.text!)! //converts the string to a double
        }
        
        
    }
    
    @IBAction func negative(_ sender: UIButton) { // if the negative button is pressed then it will convert it
        if sender.tag == 17{
            calc_view.text = String(convert_number * -1)
            convert_number = Double(calc_view.text!)! //converts string back into a double
        }
    }
   
    
    @IBAction func decimal(_ sender: UIButton) {
        calc_view.text = calc_view.text! + "."
    }
    @IBOutlet weak var calc_view: UILabel!
    
    @IBAction func other_buttons(_ sender: UIButton) {
       
        if calc_view.text != "" && sender.tag != 11 && sender.tag != 16 { //this if statement ensure that when the view is empty, the clear and equal is not pressed the following operations will occur
            first_number = Double(calc_view.text!)!
            
            //This is the divide function
            if sender.tag == 12 {
                
                calc_view.text = String(first_number) + " /" //just diplays the sign on the view
            }
                //This is the multiply function
            else if sender.tag == 13 {
                
                calc_view.text = String(first_number) + " x" //just diplays the sign on the view
                
            }
                //This is the subract function
            else if sender.tag == 14 {
                
                calc_view.text = String(first_number) + " -" //just diplays the sign on the view
            }
                //This is the add function
            else if sender.tag == 15 {
                
                calc_view.text = String(first_number) + " +" //just diplays the sign on the view
                
            }
            
           
            
            operation = sender.tag //assigns the value of the sender.tag to the operation variable which is then used below to carry out the function. This allows us to store the operation that the user chooses...or else the program will not be able to carry it out.
            
            
            
            do_math = true // makes sure that the program knows that a math operation has been activated so that it will store the first number and allow the user to enter a new number into the screen
        }
        
            //This is when the operation is conducted b/c 16 is the tag for the equal sign
        else if sender.tag == 16{
            
            if sender.tag == 17 { //if negative button is pressed then it will convert to negative
                calc_view.text = String(first_number * -1)
                first_number = Double(calc_view.text!)! //converts string into double
            }
            
            if operation == 12{ //this is the divide function
                
                calc_view.text = String(first_number / convert_number)
                
                //we are dividing the number entered first which we already converted to a double
                // by the second number which we converted to a double as well
                //finally we are converting it back to a string which is displayed on the label view
                
            }
            else if operation == 13{ //this is the multiply function
                
                calc_view.text = String(first_number * convert_number)
                
                //we are multiplying the number entered first which we already converted to a double
                // by the second number which we converted to a double as well
                //finally we are converting it back to a string which is displayed on the label view

            }
            else if operation == 14{ //this is the subtract function
                
                calc_view.text = String(first_number - convert_number)
                
                //we are subtracting the number entered first which we already converted to a double
                // by the second number which we converted to a double as well
                //finally we are converting it back to a string which is displayed on the label view

            }
            else if operation == 15{ //this is the add function
                
                calc_view.text = String(first_number + convert_number)
                
                //we are adding the number entered first which we already converted to a double
                // by the second number which we converted to a double as well
                //finally we are converting it back to a string which is displayed on the label view

            }
        }
        
        else if sender.tag == 11 { //this will reset all the values once the clear is pressed
            
            calc_view.text = ""
            first_number = 0
            operation = 0
            convert_number = 0
        }
        
    }
    
    
    override func viewDidLoad() {
        super.viewDidLoad()
        // Do any additional setup after loading the view, typically from a nib.
    }

    override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()
        // Dispose of any resources that can be recreated.
    }


}

