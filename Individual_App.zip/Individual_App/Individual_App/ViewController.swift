//
//  ViewController.swift
//  Individual_App
//
//  Created by Bharathiraja Nagappan on 10/31/17.
//  Copyright © 2017 Bharathiraja Nagappan. All rights reserved.
//

import UIKit
import MapKit
import CoreLocation
import CoreData

class ViewController: UIViewController, UIPickerViewDataSource, UIPickerViewDelegate, MKMapViewDelegate, CLLocationManagerDelegate {
    
    let locationManager: CLLocationManager = CLLocationManager() //helps keep track of user location
    
    
    @IBOutlet weak var mapView: MKMapView! //map
    
    @IBOutlet weak var deviceLabel: UILabel! //current device label
    @IBOutlet weak var deviceSelection: UIPickerView! //device selectoin
    @IBOutlet weak var distanceSlider: UISlider! //distance slider
    @IBOutlet weak var distanceLabel: UILabel! //current distance label
    /*
    @IBAction func pinGesture(_ sender: UILongPressGestureRecognizer) {
        let newPin = MKPointAnnotation()
        
    }
    */
    @IBAction func distanceChange(_ sender: UISlider) {
        var selectedValue = Float(sender.value)
        distanceLabel.text = String(stringInterpolationSegment: selectedValue)
    }
    
    let devices = ["Medtronic Minimed", "Dexcom G5", "Device 3", "Device 4", "Other"] //options for the devices
    
    func numberOfComponents(in pickerView: UIPickerView) -> Int {
        return 1
    }
    
    func pickerView(_ pickerView: UIPickerView, titleForRow row: Int, forComponent component: Int) -> String? {
        return devices[row]
    }
    
    func pickerView(_ pickerView: UIPickerView, numberOfRowsInComponent component: Int) -> Int {
        return devices.count
    }
    
    func pickerView(_ pickerView: UIPickerView, didSelectRow row: Int, inComponent component: Int) {
        deviceLabel.text = devices[row]
    }
    
    func setUpGeofenceforASU(){
        let geofenceRegionCenter = CLLocationCoordinate2DMake(33.424564, -111.928001)
        let geofenceRegion = CLCircularRegion(center: geofenceRegionCenter, radius: 100, identifier: "ASU")
        geofenceRegion.notifyOnExit = true
        geofenceRegion.notifyOnEntry = true
        
        self.locationManager.startMonitoring(for: geofenceRegion)
    }
    
    func locationManager(_ manager: CLLocationManager, didEnterRegion region: CLRegion) {
        print("Please download your data")
    }
    
    func locationManager(_ manager: CLLocationManager, didExitRegion region: CLRegion) {
        print("Thanks! See you next time")
    }
    
    //saves user location in an array call locations
    func locationManager(_ manager: CLLocationManager, didUpdateLocations locations: [CLLocation]) {
        //mapView.removeAnnotation(newPin)
        
        let location = locations[0]
        
        let span:MKCoordinateSpan = MKCoordinateSpanMake(0.01, 0.01) //defines how close we want to zoom in
        let myLocation:CLLocationCoordinate2D = CLLocationCoordinate2DMake(location.coordinate.latitude, location.coordinate.longitude) //obtains the location in map
        let region:MKCoordinateRegion = MKCoordinateRegionMake(myLocation, span)
        mapView.setRegion(region, animated: true)
        
        self.mapView.showsUserLocation = true //displays the blue dot on the map
        mapView.userTrackingMode = .follow
        
        //newPin.coordinate = location.coordinate
        //mapView.addAnnotation(newPin)
        
       
    }
    
    override func viewDidLoad() {
        
        super.viewDidLoad()
        // Do any additional setup after loading the view, typically from a nib.
        locationManager.delegate = self
        locationManager.desiredAccuracy = kCLLocationAccuracyBest
        locationManager.requestAlwaysAuthorization() //asking the user to let us track them
        locationManager.startUpdatingLocation()
       
    }
    
    func locationManager(_ manager: CLLocationManager, didChangeAuthorization status: CLAuthorizationStatus) {
        if(status == CLAuthorizationStatus.authorizedAlways){
            self.setUpGeofenceforASU()
        }
    }

    override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()
        // Dispose of any resources that can be recreated.
    }
}

